
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const path = require("path");
const { features } = require("process");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true,
}));
app.use(express.json());
app.use("/uploads", express.static("uploads")); // Serve static files

// MongoDB Connection
mongoose.connect("mongodb://localhost:27017/hospitalmanagement1", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.error("MongoDB connection error:", err));

// File Upload Config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const upload = multer({ storage });

// Schemas & Models
const User = mongoose.model("User", new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  city: String,
  state: String,
  isAdmin: { type: Boolean, default: false },
}));

const Admin = mongoose.model("Admin", new mongoose.Schema({
  email: String,
  password: String,
  hospitalName: String,
}));

const OPAppointment = mongoose.model("OPAppointment", new mongoose.Schema({
  name: String,
  age: Number,
  gender: String,
  hospital: String,
  doctor: String,
  date: String,
  time: String,
  address: String,
  location: String,
  userId: String,
}));

const AmbulanceBooking = mongoose.model("AmbulanceBooking", new mongoose.Schema({
  name: String,
  phone: String,
  address: String,
  condition: String,
  hospital: String,
  location: String,
  userId: String,
}));

const MedicineDelivery = mongoose.model("MedicineDelivery", new mongoose.Schema({
  name: String,
  hospital: String,
  location: String,
  medicines: Array,
  userId: String,
}));

const hospitalSchema = new mongoose.Schema({
  name: String,
  city: String,
  state: String,
  phone: String,
  address: String,
  availability: String,
  features: [String],
  doctors: [
    {
      name: String,
      specialization: String
    }
  ]
});

const Hospital = mongoose.model('Hospital', hospitalSchema);
// Routes

// Signup
app.post("/api/signup", async (req, res) => {
  try {
    const { name, email, password, city, state, isAdmin } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ name, email, password: hashedPassword, city, state, isAdmin });
    await newUser.save();
    res.json({ success: true, message: "Signup successful", user: newUser });
  } catch (error) {
    res.status(500).json({ success: false, message: "Signup error" });
  }
});

// Login
app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ success: false, message: "User not found" });
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ success: false, message: "Invalid credentials" });
    res.json({ success: true, message: "Login successful", user });
  } catch (error) {
    res.status(500).json({ success: false, message: "Login error" });
  }
});

// Admin Register/Login
app.post("/api/admin-register", async (req, res) => {
  const { email, password, hospitalName } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newAdmin = new Admin({ email, password: hashedPassword, hospitalName });
    await newAdmin.save();
    res.status(201).json({ message: "Admin registered successfully" });
  } catch (err) {
    res.status(500).json({ message: "Error during registration" });
  }
});

app.post("/api/admin-login", async (req, res) => {
  const { email, password } = req.body;
  const admin = await Admin.findOne({ email });
  if (!admin) return res.status(401).json({ success: false, message: "Admin not found" });
  const isMatch = await bcrypt.compare(password, admin.password);
  if (!isMatch) return res.status(401).json({ success: false, message: "Invalid credentials" });
  res.json({ success: true, message: "Login successful", admin: { email, hospitalName: admin.hospitalName, id: admin._id } });
});

// OP Appointment Booking
app.post("/api/appointments", async (req, res) => {
  try {
    const newAppointment = new OPAppointment(req.body);
    await newAppointment.save();
    res.json({ success: true, message: "Appointment booked successfully", data: newAppointment });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error booking appointment" });
  }
});
app.get("/api/appointments", async (req, res) => {
  try {
    const { userId } = req.query;
    const filter = userId ? { userId } : {};
    const appointments = await OPAppointment.find(filter);
    res.json({ success: true, data: appointments });
  } catch (err) {
    res.status(500).json({ success: false, message: "Fetch appointments error" });
  }
});


// Ambulance Booking
app.post("/api/ambulancebookings", async (req, res) => {
  try {
    const newBooking = new AmbulanceBooking(req.body);
    await newBooking.save();
    res.json({ success: true, message: "Ambulance booked!", data: newBooking });
  } catch (err) {
    console.error("Ambulance booking error:", err);
    res.status(500).json({ success: false, message: "Booking error" });
  }
});
app.get("/api/ambulancebookings", async (req, res) => {
  try {
    const { userId } = req.query;
    const filter = userId ? { userId } : {};
    const data = await AmbulanceBooking.find(filter);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, message: "Fetch error" });
  }
});



// Medicine Delivery
app.post("/api/medicinedeliveries", async (req, res) => {
  try {
    const newDelivery = new MedicineDelivery(req.body);
    await newDelivery.save();
    res.status(201).json({ success: true, message: "Medicine delivery booked successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
});
app.get("/api/medicinedeliveries", async (req, res) => {
  try {
    const { userId } = req.query;
    const filter = userId ? { userId } : {};
    const medicines = await MedicineDelivery.find(filter);
    res.json({ success: true, data: medicines });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error fetching medicines" });
  }
});



// Hospital Discovery by Location

// Add this route in your Express backend

app.get("/api/get-hospitals-by-location", async (req, res) => {
  try {
    const { location } = req.query;
    if (!location || !location.trim()) {
      return res.status(400).json({ success: false, message: "Location is required" });
    }

    const regex = new RegExp(location.trim(), "i"); // case-insensitive match
    const hospitals = await Hospital.find({
      $or: [
        { city: regex },
        { state: regex }
      ]
    });

    res.json({ success: true, data: hospitals });
  } catch (error) {
    console.error("Fetch hospitals error:", error);
    res.status(500).json({ success: false, message: "Fetch hospitals error" });
  }
});



// Admin Dashboard Counters
app.get("/api/admin/get-patients-count", async (req, res) => {
  const count = await User.countDocuments();
  res.json({ count });
});

app.get("/api/admin/get-appointments-count", async (req, res) => {
  const count = await OPAppointment.countDocuments();
  res.json({ count });
});

app.get("/api/admin/get-ambulancebookings-count", async (req, res) => {
  const count = await AmbulanceBooking.countDocuments();
  res.json({ count });
});

app.get("/api/admin/get-medicinedeliveries-count", async (req, res) => {
  const count = await MedicineDelivery.countDocuments();
  res.json({ count });
});

// Admin Specific Hospital Bookings
app.post("/api/admin-ambulance", async (req, res) => {
  const { hospitalName } = req.body;
  const data = await AmbulanceBooking.find({ hospital: hospitalName });
  res.json(data);
});

app.post("/api/admin-appointments", async (req, res) => {
  const { hospitalName } = req.body;
  const data = await OPAppointment.find({ hospital: hospitalName });
  res.json(data);
});

app.post("/api/admin-medicines", async (req, res) => {
  const { hospitalName } = req.body;
  const data = await MedicineDelivery.find({ hospital: hospitalName });
  res.json(data);
});

// File Upload Example Route (optional for future use)
app.post("/api/upload", upload.single("file"), (req, res) => {
  res.json({ filename: req.file.filename, path: req.file.path });
});

// Root Route
app.get("/", (req, res) => {
  res.send("Backend server is running!");
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});



