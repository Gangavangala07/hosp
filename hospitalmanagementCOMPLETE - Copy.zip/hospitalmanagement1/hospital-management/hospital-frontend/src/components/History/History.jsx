import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './History.css';

const History = () => {
  const [selectedHistory, setSelectedHistory] = useState('appointments');
  const [appointments, setAppointments] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [ambulances, setAmbulances] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch OP Appointments
    axios.get('http://localhost:5000/api/appointments')
      .then((res) => setAppointments(res.data.data || []))
      .catch((err) => {
        console.error("Error fetching appointments:", err);
        setError("Error fetching appointments.");
      });

    // Fetch Medicine Deliveries
    axios.get('http://localhost:5000/api/medicinedeliveries')
      .then((res) => setMedicines(res.data.data || []))
      .catch((err) => {
        console.error("Error fetching medicine deliveries:", err);
        setError("Error fetching medicine deliveries.");
      });

    // Fetch Ambulance Bookings
    axios.get('http://localhost:5000/api/ambulancebookings')
      .then((res) => setAmbulances(res.data.data || []))
      .catch((err) => {
        console.error("Error fetching ambulance bookings:", err);
        setError("Error fetching ambulance bookings.");
      });
  }, []);

  const handleChange = (e) => {
    setSelectedHistory(e.target.value);
    setError('');
  };

  const renderData = () => {
    if (selectedHistory === 'appointments') {
      return appointments.length > 0 ? appointments.map((a, index) => (
        <div className="history-card" key={index}>
          <div className="history-header">{a.hospital}</div>
          <div className="history-body">
            <p><strong>Name:</strong> {a.name}</p>
            <p><strong>Doctor:</strong> {a.doctor}</p>
            <p><strong>Date:</strong> {a.date}</p>
            <p><strong>Time:</strong> {a.time}</p>
            <p><strong>Address:</strong> {a.address}</p>
            <p><strong>Location:</strong> {a.location}</p>
          </div>
        </div>
      )) : <p className="no-data">No appointments found.</p>;
    } else if (selectedHistory === 'medicines') {
      return medicines.length > 0 ? medicines.map((m, index) => (
        <div className="history-card" key={index}>
          <div className="history-header">{m.hospital}</div>
          <div className="history-body">
            <p><strong>Name:</strong> {m.name}</p>
            <p><strong>Medicines:</strong> {m.medicines?.join(', ') || 'No medicines listed'}</p>
            <p><strong>Address:</strong> {m.address}</p>
            <p><strong>Location:</strong> {m.location}</p>
          </div>
        </div>
      )) : <p className="no-data">No medicine deliveries found.</p>;
    } else if (selectedHistory === 'ambulances') {
      return ambulances.length > 0 ? ambulances.map((a, index) => (
        <div className="history-card" key={index}>
          <div className="history-header">{a.hospital}</div>
          <div className="history-body">
            <p><strong>Name:</strong> {a.name}</p>
            <p><strong>Condition:</strong> {a.condition}</p>
            <p><strong>Address:</strong> {a.address}</p>
            <p><strong>Location:</strong> {a.location}</p>
          </div>
        </div>
      )) : <p className="no-data">No ambulance bookings found.</p>;
    }
  };

  return (
    <div className="history-container">
      <h2 className="history-title">Your Booking History</h2>

      <div className="history-controls">
        <select className="history-dropdown" value={selectedHistory} onChange={handleChange}>
          <option value="appointments">OP Appointments</option>
          <option value="medicines">Medicine Deliveries</option>
          <option value="ambulances">Ambulance Bookings</option>
        </select>
      </div>

      {error && <p className="error-message">{error}</p>}

      <div className="history-list">
        {renderData()}
      </div>
    </div>
  );
};

export default History;
