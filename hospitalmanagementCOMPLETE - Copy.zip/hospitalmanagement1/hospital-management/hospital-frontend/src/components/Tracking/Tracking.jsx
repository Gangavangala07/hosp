import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Tracking.css';

const Tracking = () => {
  const [selectedTracking, setSelectedTracking] = useState('op');
  const [appointments, setAppointments] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [ambulances, setAmbulances] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch OP Appointments
    axios.get('http://localhost:5000/api/appointments')
      .then((res) => setAppointments(res.data.data || []))
      .catch((err) => {
        console.error("Error fetching appointments:", err);
        setError("Error fetching OP appointments.");
      });

    // Fetch Medicine Deliveries
    axios.get('http://localhost:5000/api/medicinedeliveries')
      .then((res) => setMedicines(res.data.data || []))
      .catch((err) => {
        console.error("Error fetching medicine deliveries:", err);
        setError("Error fetching medicine deliveries.");
      });

    // Fetch Ambulance Bookings
    axios.get('http://localhost:5000/api/ambulancebookings')
      .then((res) => setAmbulances(res.data.data || []))
      .catch((err) => {
        console.error("Error fetching ambulance bookings:", err);
        setError("Error fetching ambulance bookings.");
      });
  }, []);

  const handleChange = (event) => {
    setSelectedTracking(event.target.value);
    setError('');
  };

  // Generate mock status for each service type (can be customized further)
  const getStatus = (type) => {
    switch(type) {
      case 'op':
        return 'Scheduled';  // Example: OP Appointment status
      case 'medicine':
        return 'Out for Delivery';  // Example: Medicine Delivery status
      case 'ambulance':
        return 'On the Way';  // Example: Ambulance Booking status
      default:
        return 'Pending';
    }
  };

  return (
    <div className="tracking-container">
      <h2 className="tracking-title">Service Tracking</h2>

      <select className="tracking-dropdown" value={selectedTracking} onChange={handleChange}>
        <option value="op">OP Appointments</option>
        <option value="medicine">Medicine Deliveries</option>
        <option value="ambulance">Ambulance Bookings</option>
      </select>

      {error && <p className="error-message">{error}</p>}

      {selectedTracking === 'op' && (
        <div className="tracking-section">
          <h3>OP Appointments</h3>
          {appointments.length === 0 ? (
            <p>No OP appointments available.</p>
          ) : (
            <ul>
              {appointments.map((a, index) => (
                <li key={index} className="tracking-card">
                  <div className="tracking-card-header">{a.hospital}</div>
                  <div className="tracking-card-details">
                    <strong>Name:</strong> {a.name} <br />
                    <strong>Doctor:</strong> {a.doctor} <br />
                    <strong>Date:</strong> {a.date} <br />
                    <strong>Time:</strong> {a.time} <br />
                    <strong>Address:</strong> {a.address} <br />
                    <strong>Location:</strong> {a.location} <br />
                    <strong>Status:</strong> {getStatus('op')}  {/* Custom status */}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {selectedTracking === 'medicine' && (
        <div className="tracking-section">
          <h3>Medicine Deliveries</h3>
          {medicines.length === 0 ? (
            <p>No medicine deliveries available.</p>
          ) : (
            <ul>
              {medicines.map((m, index) => (
                <li key={index} className="tracking-card">
                  <div className="tracking-card-header">{m.hospital}</div>
                  <div className="tracking-card-details">
                    <strong>Name:</strong> {m.name} <br />
                    <strong>Medicines:</strong> {m.medicines?.join(', ') || 'No medicines listed'} <br />
                    <strong>Address:</strong> {m.address} <br />
                    <strong>Location:</strong> {m.location} <br />
                    <strong>Status:</strong> {getStatus('medicine')}  {/* Custom status */}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {selectedTracking === 'ambulance' && (
        <div className="tracking-section">
          <h3>Ambulance Bookings</h3>
          {ambulances.length === 0 ? (
            <p>No ambulance bookings available.</p>
          ) : (
            <ul>
              {ambulances.map((a, index) => (
                <li key={index} className="tracking-card">
                  <div className="tracking-card-header">{a.hospital}</div>
                  <div className="tracking-card-details">
                    <strong>Name:</strong> {a.name} <br />
                    <strong>Condition:</strong> {a.condition} <br />
                    <strong>Address:</strong> {a.address} <br />
                    <strong>Location:</strong> {a.location} <br />
                    <strong>Status:</strong> {getStatus('ambulance')}  {/* Custom status */}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};

export default Tracking;
