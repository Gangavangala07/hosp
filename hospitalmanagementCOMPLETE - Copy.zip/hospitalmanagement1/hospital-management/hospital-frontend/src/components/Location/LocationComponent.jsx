// src/components/LocationComponent.js
import React, { useState, useEffect } from 'react';

const LocationComponent = ({ onLocationUpdate }) => {
  const [manualCity, setManualCity] = useState('');
  const [location, setLocation] = useState({
    city: '',
    state: '',
    latitude: '',
    longitude: '',
  });

  // Load saved location on mount
  useEffect(() => {
    const savedLocation = localStorage.getItem('user-location');
    if (savedLocation) {
      setLocation((prev) => ({ ...prev, city: savedLocation }));
      onLocationUpdate(savedLocation);
    } else {
      getLocation();
    }
  }, []);

  const getLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;

          // You can optionally use reverse geocoding here via external API
          const updatedLocation = {
            latitude,
            longitude,
            city: 'Hyderabad', // Replace with actual city if reverse geocoding
            state: 'Telangana',
          };

          setLocation(updatedLocation);
          const formatted = `${updatedLocation.city}, ${updatedLocation.state}`;
          localStorage.setItem('user-location', formatted);
          onLocationUpdate(formatted);
        },
        (error) => {
          console.error('Geolocation error:', error);
          alert('Could not get current location. Please enter manually.');
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const handleManualChange = (e) => {
    setManualCity(e.target.value);
  };

  const handleManualSubmit = (e) => {
    e.preventDefault();
    const updatedLocation = {
      ...location,
      city: manualCity,
      state: '',
    };
    setLocation(updatedLocation);
    localStorage.setItem('user-location', manualCity);
    onLocationUpdate(manualCity);
  };

  return (
    <div className="location-box">
      <h2>📍 Your Location</h2>
      <div>
        <p><strong>Latitude:</strong> {location.latitude}</p>
        <p><strong>Longitude:</strong> {location.longitude}</p>
        <p><strong>City:</strong> {location.city}</p>
        <p><strong>State:</strong> {location.state}</p>
      </div>

      <div className="manual-location-form">
        <h4>Manually Update City</h4>
        <form onSubmit={handleManualSubmit}>
          <input
            type="text"
            placeholder="Enter City"
            value={manualCity}
            onChange={handleManualChange}
          />
          <button type="submit">Set Location</button>
        </form>
      </div>
    </div>
  );
};

export default LocationComponent;
