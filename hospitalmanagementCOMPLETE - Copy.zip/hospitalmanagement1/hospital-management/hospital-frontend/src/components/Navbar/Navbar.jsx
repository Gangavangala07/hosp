import React, { useState, useRef, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import './Navbar.css';  // This is fine if it's only used in the Navbar component

const Navbar = () => {
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef(null);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("userToken");
    localStorage.removeItem("isAdminLoggedIn");
    navigate("/");
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setProfileOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const isAdmin = localStorage.getItem("isAdminLoggedIn");
  const isUser = localStorage.getItem("userToken");

  return (
    <nav className="navbar">
      <div className="navbar-brand">🏥 HealthConnect</div>

      <div className="nav-links">
        {/* ✅ User Routes */}
        {isUser && (
          <>
            <NavLink to="/hospitals">Hospitals</NavLink>
            <NavLink to="/doctors">Doctors</NavLink>
            <NavLink to="/appointment">OP Booking</NavLink>
            <NavLink to="/ambulance">Ambulance</NavLink>
            <NavLink to="/medicine">Medicines</NavLink>
            <NavLink to="/tracking">Tracking</NavLink>
            <NavLink to="/admin">Admin </NavLink>
          </>
        )}

        
      </div>

      {/* Profile Dropdown */}
      {(isUser || isAdmin) && (
        <div className={`profile-dropdown ${profileOpen ? 'open' : ''}`} ref={profileRef}>
          <span
            className="profile-link"
            onClick={() => {
              setProfileOpen(!profileOpen);
            }}
          >
            Profile ▾
          </span>
          {profileOpen && (
            <div className="profile-dropdown-menu">
              {isUser && <NavLink to="/profile" className="dropdown-item">Account Details</NavLink>}
              {isUser && <NavLink to="/history" className="dropdown-item">History</NavLink>}
              <div className="dropdown-item" onClick={handleLogout}>Logout</div>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
