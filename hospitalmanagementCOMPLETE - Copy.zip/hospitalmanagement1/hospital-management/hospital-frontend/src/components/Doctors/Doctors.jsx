import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Doctors.css';

const doctors = [
  { id: 1, name: 'Dr. Anjali Mehta', specialization: 'Cardiologist', hospital: 'Apollo Hospital, Hyderabad', availability: 'Mon-Fri, 10AM - 2PM', contact: 'anjali@apollo.com | +91 9876543210' },
  { id: 2, name: 'Dr. Ravi Kumar', specialization: 'Orthopedic Surgeon', hospital: 'Care Hospitals, Hyderabad', availability: 'Mon-Sat, 9AM - 1PM', contact: 'ravi.kumar@carehospitals.in | +91 9123456780' },
  { id: 3, name: 'Dr. Sneha Reddy', specialization: 'Pediatrician', hospital: 'Rainbow Children’s Hospital, Hyderabad', availability: 'Tue-Fri, 11AM - 4PM', contact: 'sneha.reddy@rainbow.in | +91 9845012345' },
  { id: 4, name: 'Dr. Mohan Das', specialization: 'Neurologist', hospital: 'NIMHANS, Hyderabad', availability: 'Mon-Fri, 10AM - 3PM', contact: 'mohan@nimhans.in | +91 9900011122' },
  { id: 5, name: 'Dr. Priya Shah', specialization: 'Dermatologist', hospital: 'Kokilaben Hospital, Hyderabad', availability: 'Tue-Sat, 10AM - 1PM', contact: 'priya.shah@kokilaben.com | +91 9876001122' },
  { id: 6, name: 'Dr. Arjun Nair', specialization: 'ENT Specialist', hospital: 'Aster Medcity, Hyderabad', availability: 'Mon-Fri, 9AM - 12PM', contact: 'arjun.nair@aster.in | +91 9988776655' },
  { id: 7, name: 'Dr. Meera Joshi', specialization: 'Gynecologist', hospital: 'Cloudnine Hospital, Hyderabad', availability: 'Mon-Sat, 10AM - 3PM', contact: 'meera.joshi@cloudnine.in | +91 9811122233' },
  { id: 8, name: 'Dr. Farhan Sheikh', specialization: 'Urologist', hospital: 'Max Hospital, Hyderabad', availability: 'Tue-Fri, 11AM - 2PM', contact: 'farhan.sheikh@max.in | +91 9876543012' },
  { id: 9, name: 'Dr. Lakshmi Iyer', specialization: 'Oncologist', hospital: 'Tata Memorial Hospital, Hyderabad', availability: 'Mon-Fri, 10AM - 4PM', contact: 'lakshmi.iyer@tatamemorial.org | +91 9100087654' },
  { id: 10, name: 'Dr. Rohan Verma', specialization: 'Endocrinologist', hospital: 'AIIMS, Hyderabad', availability: 'Mon-Thu, 9AM - 1PM', contact: 'rohan.verma@aiims.edu | +91 9911223344' },
  { id: 11, name: 'Dr. Sunita Desai', specialization: 'Psychologist', hospital: 'Manipal Hospital, Hyderabad', availability: 'Mon-Fri, 11AM - 5PM', contact: 'sunita.desai@manipal.in | +91 9000011112' },
  { id: 12, name: 'Dr. Varun Kapoor', specialization: 'Radiologist', hospital: 'Apollo Spectra, Hyderabad', availability: 'Mon-Sat, 10AM - 2PM', contact: 'varun.kapoor@apollo.in | +91 9912333444' },
  { id: 13, name: 'Dr. Alka Mishra', specialization: 'Pulmonologist', hospital: 'Fortis Escorts, Hyderabad', availability: 'Mon-Fri, 9AM - 12PM', contact: 'alka.mishra@fortis.in | +91 9765432109' },
  { id: 14, name: 'Dr. Rajeev Ranjan', specialization: 'Gastroenterologist', hospital: 'Medicover Hospitals, Hyderabad', availability: 'Mon-Sat, 11AM - 3PM', contact: 'rajeev.ranjan@medicover.in | +91 9012345678' },
  { id: 15, name: 'Dr. Nandita Rao', specialization: 'Nephrologist', hospital: 'SevenHills Hospital, Hyderabad', availability: 'Mon-Fri, 10AM - 1PM', contact: 'nandita.rao@sevenhills.in | +91 8899001122' },
  { id: 16, name: 'Dr. Vivek Bhalla', specialization: 'Ophthalmologist', hospital: 'Shankar Netralaya, Hyderabad', availability: 'Tue-Sat, 9AM - 1PM', contact: 'vivek.bhalla@snmail.org | +91 9900887766' },
  { id: 17, name: 'Dr. Snehal Patil', specialization: 'Dentist', hospital: 'Clove Dental, Hyderabad', availability: 'Mon-Sat, 10AM - 6PM', contact: 'snehal.patil@clovedental.in | +91 9123456700' },
  { id: 18, name: 'Dr. Akash Khanna', specialization: 'General Physician', hospital: 'Care Hospitals, Hyderabad', availability: 'Mon-Sat, 9AM - 2PM', contact: 'akash.khanna@carehospitals.in | +91 9876701234' },
  { id: 19, name: 'Dr. Namrata Singh', specialization: 'Psychiatrist', hospital: 'Narayana Health, Hyderabad', availability: 'Mon-Fri, 10AM - 3PM', contact: 'namrata.singh@narayana.in | +91 9304567890' },
  { id: 20, name: 'Dr. Shyam Menon', specialization: 'Anesthesiologist', hospital: 'Sunshine Hospitals, Hyderabad', availability: 'Mon-Fri, 10AM - 4PM', contact: 'shyam.menon@sunshine.in | +91 9080706050' },
  { id: 21, name: 'Dr. Kavya Pillai', specialization: 'Hematologist', hospital: 'KIMS Hospital, Hyderabad', availability: 'Mon-Fri, 11AM - 3PM', contact: 'kavya.pillai@kims.in | +91 9800112233' },
  { id: 22, name: 'Dr. Neeraj Gupta', specialization: 'Rheumatologist', hospital: 'Yashoda Hospitals, Hyderabad', availability: 'Tue-Sat, 9AM - 12PM', contact: 'neeraj.gupta@yashoda.in | +91 9876543123' },
  { id: 23, name: 'Dr. Anuja Banerjee', specialization: 'Allergist', hospital: 'AMRI Hospital, Hyderabad', availability: 'Mon-Fri, 10AM - 2PM', contact: 'anuja.banerjee@amri.in | +91 9123009876' },
  { id: 24, name: 'Dr. Imran Qureshi', specialization: 'Infectious Disease Specialist', hospital: 'Columbia Asia, Hyderabad', availability: 'Mon-Sat, 10AM - 1PM', contact: 'imran.qureshi@columbia.in | +91 9911002233' },
  { id: 25, name: 'Dr. Vishal Soni', specialization: 'Psychiatrist', hospital: 'Medanta Hospital, Hyderabad', availability: 'Mon-Fri, 10AM - 4PM', contact: 'vishal@medanta.com | +91 9912345678' },
  { id: 26, name: 'Dr. Rajesh Iyer', specialization: 'Gastroenterologist', hospital: 'KIMS Hospital, Hyderabad', availability: 'Mon-Fri, 9AM - 3PM', contact: 'rajesh.iyer@kims.in | +91 9000887766' },
  { id: 27, name: 'Dr. Suman Jain', specialization: 'Orthopedic Surgeon', hospital: 'Care Hospitals, Hyderabad', availability: 'Mon-Sat, 9AM - 2PM', contact: 'suman.jain@carehospitals.in | +91 9845678765' },
  { id: 28, name: 'Dr. Rohit Sharma', specialization: 'Cardiologist', hospital: 'Global Hospitals, Hyderabad', availability: 'Mon-Fri, 10AM - 1PM', contact: 'rohit.sharma@globalhospitals.in | +91 9900112233' },
  { id: 29, name: 'Dr. Shruti Agarwal', specialization: 'Pediatrician', hospital: 'Rainbow Children’s Hospital, Hyderabad', availability: 'Tue-Fri, 11AM - 3PM', contact: 'shruti.agarwal@rainbow.in | +91 9845321098' },
  { id: 30, name: 'Dr. Vikas Rathi', specialization: 'General Surgeon', hospital: 'Manipal Hospitals, Hyderabad', availability: 'Mon-Fri, 9AM - 3PM', contact: 'vikas.rathi@manipal.in | +91 9998775566' }
];


 const Doctors = () => {
     const [filteredDoctors, setFilteredDoctors] = useState(doctors);
     const [searchQuery, setSearchQuery] = useState('');
     const navigate = useNavigate();
 
     // Handle search input change
     const handleSearch = (e) => {
         const query = e.target.value.toLowerCase();
         setSearchQuery(query);
 
         const filtered = doctors.filter(
             (doctor) =>
                 doctor.name.toLowerCase().includes(query) ||
                 doctor.specialization.toLowerCase().includes(query) ||
                 doctor.hospital.toLowerCase().includes(query)
         );
 
         setFilteredDoctors(filtered);
     };
     const defaultedDoctors = doctors.map(doc => ({
      ...doc,
      department: doc.department || doc.specialization + ' Department'
    }));
    
     // Handle Book Appointment button click
     const handleBookAppointment = (doctor) => {
         // Navigate to OPBookingForm, passing doctor info as state
         navigate('/opbookingform', { state: { 
             doctorName: doctor.name, 
             hospitalName: doctor.hospital, 
             location: doctor.hospital.split(', ')[1] // Extract location from hospital (Hyderabad)
         } });
     };
 
     return (
         <div className="doctors-container">
             <div className="search-bar">
                 <input
                     type="text"
                     placeholder="Search for a doctor..."
                     value={searchQuery}
                     onChange={handleSearch}
                 />
             </div>
 
             <div className="doctor-list">
                 {filteredDoctors.length === 0 ? (
                     <p>No doctors found.</p>
                 ) : (
                     filteredDoctors.map((doctor) => (
                         <div key={doctor.id} className="doctor-card">
                             <h3>{doctor.name}</h3>
                             <p><strong>Specialization:</strong> {doctor.specialization}</p>
                             <p><strong>Hospital:</strong> {doctor.hospital}</p>
                             <p><strong>Availability:</strong> {doctor.availability}</p>
                             {/* Book Appointment button */}
                             <button
                                 className="book-appointment-btn"
                                 onClick={() => handleBookAppointment(doctor)}
                             >
                                 Book Appointment
                             </button>
                         </div>
                     ))
                 )}
             </div>
         </div>
     );
 };
 
 export default Doctors;
 
