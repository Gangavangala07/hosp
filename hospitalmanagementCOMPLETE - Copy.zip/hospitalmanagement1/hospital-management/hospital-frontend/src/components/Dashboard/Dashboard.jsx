import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();

  const handleNavigate = () => {
    // Assuming you want to pass the hospital name when navigating
    const hospitalName = localStorage.getItem('hospitalName');
    navigate('/hospitals', { state: { hospitalName } }); // Passing hospitalName via state
  };

  return (
    <div className="dashboard-container user-dashboard">
      <div className="welcome-content">
        <h1>Welcome to the Hospital Management App!</h1>
        <p>Manage your hospital's appointments, ambulance, and medicine deliveries seamlessly.</p>
        <p>Stay on top of patient care and hospital operations with ease.</p>

        <button onClick={handleNavigate} className="navigate-btn">
          Go to Hospitals
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
