import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './OPBookingForm.css';

const OPBookingForm = () => {
  const location = useLocation();
  const { hospitalName, doctorName, location: hospitalLocation } = location.state || {};

  const api = "http://localhost:5000/api/appointments";  // Correct API URL based on the backend route

  const [form, setForm] = useState({
    name: '',
    age: '',
    date: '',
    time: '',
    hospital: hospitalName || '',
    doctor: doctorName || '',
    location: hospitalLocation || '',
    address: ''  // New field for Address
  });

  const [paymentStatus, setPaymentStatus] = useState(null);  // Track payment status
  const [isPaymentConfirmed, setIsPaymentConfirmed] = useState(false); // Track payment confirmation
  const [isAppointmentBooked, setIsAppointmentBooked] = useState(false); // Track if appointment is booked

  const timeSlots = ['9:00 AM - 11:00 AM', '12:00 PM - 2:00 PM', '4:00 PM - 6:00 PM', '8:00 PM - 9:00 PM'];

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const userId = localStorage.getItem("userId");
    if (!userId) {
      alert("User not logged in. Please login to book an appointment.");
      return;
    }

    const bookingData = {
      ...form,
      userId: userId,  // Add userId to the request body
    };

    try {
      // Correct API URL
      const response = await fetch(api, {  // Changed to match backend '/api/appointments'
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bookingData),
      });

      // Check if the response is successful
      if (!response.ok) {
        const errorData = await response.text();  // If not JSON, show response text for debugging
        console.error('Error response:', errorData);
        alert('Error booking appointment. Server returned an error response.');
        return;
      }

      // Parse JSON response
      const result = await response.json();

      if (result.success) {
        alert("Appointment booked successfully");
        setIsAppointmentBooked(true); // Mark the appointment as booked
        setForm({
          name: '',
          age: '',
          date: '',
          time: '',
          hospital: hospitalName || '',
          doctor: doctorName || '',
          location: hospitalLocation || '',
          address: ''  // Reset address after booking
        });
      } else {
        alert(result.message || 'Error booking appointment.');
      }
    } catch (error) {
      console.error('Error submitting appointment:', error);
      alert(`Error: ${error.message || 'Server error! Please try again.'}`);
    }
  };

  // Handle Dummy Payment
  const handleDummyPayment = () => {
    setPaymentStatus(" 💥Payment successful! Your appointment is confirmed.");
    setIsPaymentConfirmed(true);  // Mark payment as confirmed
    setIsAppointmentBooked(false);  // Reset the appointment booked flag after payment
  };

  // Disable yesterday's date
  const disableYesterday = () => {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();
    return `${yyyy}-${mm}-${dd}`;  // Returns current date to disable past dates
  };

  useEffect(() => {
    if (location.state) {
      setForm((prevForm) => ({
        ...prevForm,
        hospital: hospitalName || prevForm.hospital,
        doctor: doctorName || prevForm.doctor,
        location: hospitalLocation || prevForm.location
      }));
    }
  }, [location, hospitalName, doctorName, hospitalLocation]);

  return (
    <div className="op-booking-container">
      <form className="booking-form" onSubmit={handleSubmit}>
        <h2>🩺 OP Appointment Booking</h2>

        <div className="form-group">
          <label>Hospital Name</label>
          <input
            type="text"
            name="hospital"
            value={form.hospital}
            onChange={handleChange}
            placeholder="Enter Hospital Name"
            required
          />
        </div>

        <div className="form-group">
          <label>Doctor Name</label>
          <input
            type="text"
            name="doctor"
            value={form.doctor}
            onChange={handleChange}
            placeholder="Enter Doctor Name"
            required
          />
        </div>

        <div className="form-group">
          <label>Location</label>
          <input
            type="text"
            name="location"
            value={form.location}
            onChange={handleChange}
            placeholder="Enter Location"
            required
          />
        </div>

        <div className="form-group">
          <label>Address</label>
          <input
            type="text"
            name="address"
            value={form.address}
            onChange={handleChange}
            placeholder="Enter your Address"
            required
          />
        </div>

        <div className="form-group">
          <label>Full Name</label>
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Age</label>
          <input
            type="number"
            name="age"
            value={form.age}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Appointment Date</label>
          <input
            type="date"
            name="date"
            value={form.date}
            onChange={handleChange}
            required
            min={disableYesterday()}  // Disable yesterday's date
          />
        </div>

        <div className="form-group">
          <label>Appointment Time Slot</label>
          <select
            name="time"
            value={form.time}
            onChange={handleChange}
            required
          >
            <option value="">-- Select Time Slot --</option>
            {timeSlots.map((slot, index) => (
              <option key={index} value={slot}>{slot}</option>
            ))}
          </select>
        </div>

        <button type="submit" className="submit-btn">Book Appointment</button>

        {/* Pay button only visible after the appointment is successfully booked */}
        {isAppointmentBooked && !isPaymentConfirmed && (
          <button
            type="button"
            className="pay-btn"
            onClick={handleDummyPayment}
          >
            Pay & Confirm Appointment
          </button>
        )}

        {/* Show payment status after payment */}
        {paymentStatus && <div className="payment-status">{paymentStatus}</div>}
   
      </form>
    </div>
  );
};

export default OPBookingForm;
