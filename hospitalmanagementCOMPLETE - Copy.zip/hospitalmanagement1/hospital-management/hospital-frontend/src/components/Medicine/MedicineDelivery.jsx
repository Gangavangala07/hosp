import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './MedicineDelivery.css';

const MedicineDelivery = () => {
  const location = useLocation();  // Get the location object from the router
  const [form, setForm] = useState({
    name: '',
    address: '',
    deliveryDate: '',
    location: '',
    hospital: '',
    doctor: '',
    medicines: [{ name: '', quantity: 1 }],
    prescription: null
  });

  const [isPaymentConfirmed, setIsPaymentConfirmed] = useState(false);
  const [isOrderPlaced, setIsOrderPlaced] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [previewFile, setPreviewFile] = useState(null);

  // This handles changes for fields other than the medicines array
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm((prevForm) => ({
      ...prevForm,
      [name]: value
    }));
  };

  // This handles changes for the medicines array
  const handleMedicineChange = (e, index) => {
    const { name, value } = e.target;
    const updatedMedicines = [...form.medicines];
    
    if (updatedMedicines[index]) {
      updatedMedicines[index][name] = value;
      setForm({ ...form, medicines: updatedMedicines });
    }
  };

  const handleAddMedicine = () => {
    setForm({ ...form, medicines: [...form.medicines, { name: '', quantity: 1 }] });
  };

  const handleRemoveMedicine = (index) => {
    const updatedMedicines = form.medicines.filter((_, i) => i !== index);
    setForm({ ...form, medicines: updatedMedicines });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setForm({ ...form, prescription: file });
    setPreviewFile(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const userId = localStorage.getItem("userId");
    if (!userId) {
      alert("User not logged in. Please login to place the order.");
      return;
    }

    const orderData = {
      ...form,
      userId: userId
    };

    try {
      const response = await fetch("http://localhost:5000/api/medicinedeliveries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData)
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Error response:', errorData);
        alert('Error placing the medicine order. Server returned an error response.');
        return;
      }

      const result = await response.json();

      if (result.success) {
        alert("Medicine delivery order placed successfully");
        setIsOrderPlaced(true);
        setForm({
          name: '',
          address: '',
          deliveryDate: '',
          location: '',
          hospital: '',
          doctor: '',
          medicines: [{ name: '', quantity: 1 }],
          prescription: null
        });
      } else {
        alert(result.message || 'Error placing order.');
      }
    } catch (error) {
      console.error('Error submitting order:', error);
      alert(`Error: ${error.message || 'Server error! Please try again.'}`);
    }
  };

  const handleDummyPayment = () => {
    setPaymentStatus("💥 Payment successful! Your medicine delivery is confirmed.");
    setIsPaymentConfirmed(true);
    setIsOrderPlaced(false);
  };

  const disableYesterday = () => {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();
    return `${yyyy}-${mm}-${dd}`;
  };

  // If location has state passed from the previous page (e.g., HospitalCard), pre-fill hospital and location
  useEffect(() => {
    if (location.state) {
      const { hospitalName, location: locationName } = location.state;
      setForm((prevForm) => ({
        ...prevForm,
        hospital: hospitalName || prevForm.hospital,
        location: locationName || prevForm.location
      }));
    }
  }, [location.state]);

  return (
    <div className="medicine-delivery-container">
      <form className="delivery-form" onSubmit={handleSubmit}>
        <h2>💊 Medicine Delivery</h2>

        <div className="form-group">
          <label>Full Name</label>
          <input type="text" name="name" value={form.name} onChange={handleInputChange} required />
        </div>

        <div className="form-group">
          <label>Address</label>
          <input type="text" name="address" value={form.address} onChange={handleInputChange} placeholder="Enter delivery address" required />
        </div>

        <div className="form-group">
          <label>Location</label>
          <input type="text" name="location" value={form.location} onChange={handleInputChange} placeholder="e.g. Karimnagar, Telangana" required />
        </div>

        <div className="form-group">
          <label>Hospital</label>
          <input type="text" name="hospital" value={form.hospital} onChange={handleInputChange} required />
        </div>

        <div className="form-group">
          <label>Doctor Name</label>
          <input type="text" name="doctor" value={form.doctor} onChange={handleInputChange} required />
        </div>

        <div className="form-group">
          <label>Medicines</label>
          {form.medicines.map((medicine, index) => (
            <div key={index} className="medicine-item">
              <input
                type="text"
                name="name"
                placeholder="Medicine Name"
                value={medicine.name}
                onChange={(e) => handleMedicineChange(e, index)}
                required
              />
              <input
                type="number"
                name="quantity"
                value={medicine.quantity}
                min="1"
                onChange={(e) => handleMedicineChange(e, index)}
                required
              />
              {index > 0 && (
                <button type="button" onClick={() => handleRemoveMedicine(index)} className="remove-medicine-btn">
                  Remove
                </button>
              )}
            </div>
          ))}
          <button type="button" onClick={handleAddMedicine} className="add-medicine-btn">
            Add Another Medicine
          </button>
        </div>

        <div className="form-group">
          <label>Prescription (PDF or Image)</label>
          <input type="file" name="prescription" onChange={handleFileChange} accept=".pdf, .jpeg, .jpg, .png" required />
          {previewFile && <img src={previewFile} alt="Prescription preview" width="100" />}
        </div>

        <div className="form-group">
          <label>Delivery Date</label>
          <input type="date" name="deliveryDate" value={form.deliveryDate} onChange={handleInputChange} required min={disableYesterday()} />
        </div>

        <button type="submit" className="submit-btn">Place Order</button>

        {isOrderPlaced && !isPaymentConfirmed && (
          <button type="button" className="pay-btn" onClick={handleDummyPayment}>
            Pay & Confirm Delivery
          </button>
        )}

        {paymentStatus && <div className="payment-status">{paymentStatus}</div>}
      </form>
    </div>
  );
};

export default MedicineDelivery;
