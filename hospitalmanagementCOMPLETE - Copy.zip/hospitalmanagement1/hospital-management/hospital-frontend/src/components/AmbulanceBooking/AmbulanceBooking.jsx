import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './AmbulanceBooking.css';

const AmbulanceBooking = () => {
  const location = useLocation();
  const { hospitalName, location: hospitalLocation } = location.state || {};

  const api = "http://localhost:5000/api/ambulancebookings"; // Replace with your correct backend API

  const [form, setForm] = useState({
    name: '',
    phone: '',
    condition: '',
    hospital: hospitalName || '',
    location: hospitalLocation || '',
    address: '',  // New Address field
  });

  const [isBooked, setIsBooked] = useState(false);
  const [isPaymentConfirmed, setIsPaymentConfirmed] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const userId = localStorage.getItem("userId");
    if (!userId) {
      alert("User not logged in. Please login to book an ambulance.");
      return;
    }

    const bookingData = {
      ...form,
      userId: userId,
    };

    try {
      const response = await fetch(api, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bookingData),
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error("Error response:", errText);
        alert("Error booking ambulance. Please try again.");
        return;
      }

      const result = await response.json();

      if (result.success) {
        alert("🚑 Ambulance booked successfully!");
        setIsBooked(true);
        setForm({
          name: '',
          phone: '',
          condition: '',
          hospital: hospitalName || '',
          location: hospitalLocation || '',
          address: '',
        });
      } else {
        alert(result.message || "Error booking ambulance.");
      }
    } catch (error) {
      console.error("Error booking:", error);
      alert("Server error! Please try again.");
    }
  };

  const handleDummyPayment = () => {
    setPaymentStatus("✅ Payment successful! Your ambulance is on the way.");
    setIsPaymentConfirmed(true);
    setIsBooked(false); // Reset booking flag so Pay button doesn't show again
  };

  useEffect(() => {
    if (location.state) {
      setForm((prev) => ({
        ...prev,
        hospital: hospitalName || prev.hospital,
        location: hospitalLocation || prev.location,
      }));
    }
  }, [location, hospitalName, hospitalLocation]);

  return (
    <div className="ambulance-booking-container">
      <form className="booking-form" onSubmit={handleSubmit}>
        <h2>🚑 Ambulance Booking</h2>

        <div className="form-group">
          <label>Full Name</label>
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Enter your Name"
            required
          />
        </div>
        
        <div className="form-group">
          <label>Hospital Name</label>
          <input
            type="text"
            name="hospital"
            value={form.hospital}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Location</label>
          <input
            type="text"
            name="location"
            value={form.location}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Address</label>
          <input
            type="text"
            name="address"
            value={form.address}
            onChange={handleChange}
            placeholder="Enter your Address"
            required
          />
        </div>

        

        <div className="form-group">
          <label>Phone Number</label>
          <input
            type="tel"
            name="phone"
            value={form.phone}
            onChange={handleChange}
            placeholder="Enter your Phone Number"
            required
          />
        </div>

        <div className="form-group">
          <label>Condition (Emergency or Discharge)</label>
          <select
            name="condition"
            value={form.condition}
            onChange={handleChange}
            required
          >
            <option value="">-- Select Condition --</option>
            <option value="Emergency">Emergency</option>
            <option value="Discharge">Discharge</option>
          </select>
        </div>

        <button type="submit" className="submit-btn">Book Ambulance</button>

        {isBooked && !isPaymentConfirmed && (
          <button
            type="button"
            className="pay-btn"
            onClick={handleDummyPayment}
          >
            Pay & Confirm
          </button>
        )}

        {paymentStatus && <div className="payment-status">{paymentStatus}</div>}
      </form>
    </div>
  );
};

export default AmbulanceBooking;
