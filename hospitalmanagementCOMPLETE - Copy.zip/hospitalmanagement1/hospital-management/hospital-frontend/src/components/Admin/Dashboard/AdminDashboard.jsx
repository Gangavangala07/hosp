import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './AdminDashboard.css'; // Import the CSS file for styling

const AdminDashboard = () => {
  const [adminData, setAdminData] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if admin is logged in
    const admin = JSON.parse(localStorage.getItem('admin'));
    if (!admin) {
      // If no admin is logged in, redirect to login page
      navigate('/admin-login');
    } else {
      // Set the admin data if logged in
      setAdminData(admin);
    }
  }, [navigate]);

  if (!adminData) {
    return <div>Loading...</div>;
  }

  // Handle button click to navigate to specific pages
  const handleNavigation = (route) => {
    navigate(route);
  };

  return (
    <div className="admin-dashboard-dashboard-container">
      <h1>Welcome to the Admin Dashboard</h1>
      

      <div className="button-container">
        <button className="dashboard-button" onClick={() => handleNavigation('/admin/appointments')}>
          OP Booking
        </button>
        <button className="dashboard-button" onClick={() => handleNavigation('/admin/ambulance')}>
          Ambulance Booking
        </button>
        <button className="dashboard-button" onClick={() => handleNavigation('/admin/medicines')}>
          Medicine Delivery
        </button>
      </div>
    </div>
  );
};

export default AdminDashboard;
