import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Appointment.css'; // Import the CSS file for styling

const Appointments = () => {
  const [data, setData] = useState([]);
  const hospitalName = localStorage.getItem('hospitalName');
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .post('http://localhost:5000/api/admin-appointments', { hospitalName })
      .then((res) => {
        if (res.data.length > 0) {
          setData(res.data);
        } else {
          const dummyData = getDummyData(hospitalName);
          setData(dummyData);
        }
      })
      .catch((err) => {
        console.error(err);
        const dummyData = getDummyData(hospitalName);
        setData(dummyData);
      });
  }, [hospitalName]);

  const getDummyData = (hospitalName) => {
    return [
      { name: 'John Doe', date: '2025-04-20', time: '10:00 AM', hospitalName: 'IMS Hospital' },
      { name: 'Jane Smith', date: '2025-04-20', time: '11:00 AM', hospitalName: 'Apollo Hospital' },
      { name: 'Alice Johnson', date: '2025-04-20', time: '12:00 PM', hospitalName: 'Care Hospital' },
      { name: 'Bob Brown', date: '2025-04-21', time: '10:00 AM', hospitalName: 'KIMS Hospitals' },
      { name: 'Charlie Green', date: '2025-04-21', time: '11:00 AM', hospitalName: 'Yashoda Hospital' },
      { name: 'David White', date: '2025-04-21', time: '12:00 PM', hospitalName: 'Aster Prime Hospital' },
      { name: 'Emma Blue', date: '2025-04-22', time: '09:00 AM', hospitalName: 'Rainbow Children’s Hospital' },
      { name: 'Frank Black', date: '2025-04-22', time: '10:00 AM', hospitalName: 'Asian Institute of Gastroenterology' },
      { name: 'Grace Yellow', date: '2025-04-22', time: '11:00 AM', hospitalName: 'Narayana Multispeciality Hospital' },
      { name: 'Hank Red', date: '2025-04-23', time: '10:00 AM', hospitalName: 'Mediciti Hospital' },
      { name: 'Ivy Pink', date: '2025-04-23', time: '11:00 AM', hospitalName: 'Pace Hospitals' },
      { name: 'Jack Grey', date: '2025-04-23', time: '12:00 PM', hospitalName: 'Medicover Hospitals' },
      { name: 'Karen Purple', date: '2025-04-24', time: '10:00 AM', hospitalName: 'Cure Hospital' },
      { name: 'Leo Orange', date: '2025-04-24', time: '11:00 AM', hospitalName: 'Osmania General Hospital' },
      { name: 'Mona Violet', date: '2025-04-24', time: '12:00 PM', hospitalName: 'MaxCure Hospitals' },
      { name: 'Nina Brown', date: '2025-04-25', time: '10:00 AM', hospitalName: 'Global Hospital' },
      { name: 'Oscar Pink', date: '2025-04-25', time: '11:00 AM', hospitalName: 'Medwin Hospitals' },
      { name: 'Paul Green', date: '2025-04-25', time: '12:00 PM', hospitalName: 'Care Institute of Medical Sciences' },
      { name: 'Quinn Blue', date: '2025-04-26', time: '09:00 AM', hospitalName: 'Sunshine Hospital' },
      { name: 'Rita White', date: '2025-04-26', time: '10:00 AM', hospitalName: 'Rocky Hospital' },
    ];
  };

  const handleNavigate = (route) => {
    navigate(route);
  };

  return (
    <div className="appointments-container">
      <h2>OP Bookings for {hospitalName}</h2>

      {data.length > 0 ? (
        <table className="appointments-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Date</th>
              <th>Time</th>
              <th>Hospital</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, idx) => (
              <tr key={idx}>
                <td>{item.name}</td>
                <td>{item.date}</td>
                <td>{item.time}</td>
                <td>{item.hospitalName}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No appointments available.</p>
      )}

      <div className="button-container">
        <button className="navigation-button" onClick={() => handleNavigate('/admin/medicines')}>
          Medicine Deliveries
        </button>
        <button className="navigation-button" onClick={() => handleNavigate('/admin/ambulance')}>
          Ambulance Bookings
        </button>
      </div>
    </div>
  );
};

export default Appointments;
