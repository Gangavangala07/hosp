import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AdminLoginSignup.css'; // Add this for CSS styling

const AdminLoginSignup = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [hospitalName, setHospitalName] = useState('');
  const [isLogin, setIsLogin] = useState(true);  // Toggle between Login and Register
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const url = isLogin
      ? 'http://localhost:5000/api/admin-login'
      : 'http://localhost:5000/api/admin-register';

    const requestBody = isLogin
      ? { email, password }
      : { email, password, hospitalName };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      const data = await response.json();
      setLoading(false);

      if (response.ok && data.success !== false) {
        // Save admin data to local storage
        localStorage.setItem('admin', JSON.stringify(data.admin || data));
        localStorage.setItem('isAdminLoggedIn', 'true');
        navigate('/admin/admindashboard');
      } else {
        setErrorMessage(data.message || 'Something went wrong');
      }
    } catch (error) {
      console.error('Error:', error);
      setLoading(false);
      setErrorMessage('Failed to connect to the server');
    }
  };

  return (
    <div className="admin-login-signup-container">
      <h2>{isLogin ? 'Admin Login' : 'Admin Registration'}</h2>
      <form onSubmit={handleSubmit} className="form-container">
        {!isLogin && (
          <div className="form-group">
            <label>Hospital Name</label>
            <input
              type="text"
              value={hospitalName}
              onChange={(e) => setHospitalName(e.target.value)}
              required
              className="form-input"
            />
          </div>
        )}
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="form-input"
          />
        </div>
        <button type="submit" disabled={loading} className="submit-button">
          {loading ? (isLogin ? 'Logging In...' : 'Registering...') : isLogin ? 'Login' : 'Register'}
        </button>
      </form>
      <p className="switch-mode-text">
        {isLogin ? "Don't have an account?" : 'Already have an account?'}
        <button className="switch-mode-button" onClick={() => setIsLogin(!isLogin)}>
          {isLogin ? 'Register here' : 'Login here'}
        </button>
      </p>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
    </div>
  );
};

export default AdminLoginSignup;
