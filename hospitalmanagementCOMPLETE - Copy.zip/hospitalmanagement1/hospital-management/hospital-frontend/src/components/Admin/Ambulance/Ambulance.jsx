import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Ambulance.css'; // Import the CSS file for styling

const Ambulance = () => {
  const [data, setData] = useState([]);
  const hospitalName = localStorage.getItem('hospitalName');
  const navigate = useNavigate();

  // Set the dummy data directly into the state
  useEffect(() => {
    const dummyData = getDummyData(hospitalName);
    setData(dummyData);
  }, [hospitalName]);

  // Dummy data for ambulance bookings
  const getDummyData = (hospitalName) => {
    return [
      { patientName: 'Aditi Rao', ambulanceType: 'Emergency', time: '12:30 PM', location: 'Gachibowli, Hyderabad', hospitalName: 'IMS Hospital' },
      { patientName: 'Ravi Kumar', ambulanceType: 'Non-Emergency', time: '3:15 PM', location: 'Kondapur, Hyderabad', hospitalName: 'Apollo Hospital' },
      { patientName: 'Meena Singh', ambulanceType: 'Emergency', time: '8:00 AM', location: 'Madhapur, Hyderabad', hospitalName: 'Care Hospital' },
      { patientName: 'Nikhil Reddy', ambulanceType: 'Non-Emergency', time: '10:00 AM', location: 'Lingampally, Hyderabad', hospitalName: 'KIMS Hospitals' },
      { patientName: 'Harsha Vardhan', ambulanceType: 'Emergency', time: '2:30 PM', location: 'Banjara Hills, Hyderabad', hospitalName: 'Rainbow Hospitals' },
      { patientName: 'Priya Desai', ambulanceType: 'Non-Emergency', time: '9:45 AM', location: 'Ameerpet, Hyderabad', hospitalName: 'Fortis Healthcare' },
      { patientName: 'Rohan Agarwal', ambulanceType: 'Emergency', time: '1:00 PM', location: 'Jubilee Hills, Hyderabad', hospitalName: 'Global Hospitals' },
      { patientName: 'Pooja Shah', ambulanceType: 'Non-Emergency', time: '11:30 AM', location: 'Secunderabad, Hyderabad', hospitalName: 'Care Hospitals' },
      { patientName: 'Sandeep Kumar', ambulanceType: 'Emergency', time: '7:00 AM', location: 'LB Nagar, Hyderabad', hospitalName: 'Osmania General Hospital' },
      { patientName: 'Sujatha Reddy', ambulanceType: 'Non-Emergency', time: '4:15 PM', location: 'Nallagandla, Hyderabad', hospitalName: 'Maxcure Hospitals' },
      { patientName: 'Vishal Reddy', ambulanceType: 'Emergency', time: '12:00 PM', location: 'Madhapur, Hyderabad', hospitalName: 'AIG Hospitals' },
      { patientName: 'Tanuja Rao', ambulanceType: 'Non-Emergency', time: '8:30 AM', location: 'Kondapur, Hyderabad', hospitalName: 'Shree Hospitals' },
      { patientName: 'Srinivas Reddy', ambulanceType: 'Emergency', time: '6:00 PM', location: 'KPHB, Hyderabad', hospitalName: 'NIMS Hospital' },
      { patientName: 'Lakshmi Prasad', ambulanceType: 'Non-Emergency', time: '5:00 PM', location: 'Malkajgiri, Hyderabad', hospitalName: 'Yashoda Hospitals' },
      { patientName: 'Anjali Kumari', ambulanceType: 'Emergency', time: '2:00 PM', location: 'Hitech City, Hyderabad', hospitalName: 'Medicover Hospitals' },
      { patientName: 'Vamsi Krishna', ambulanceType: 'Non-Emergency', time: '3:45 PM', location: 'Kukatpally, Hyderabad', hospitalName: 'Sri Krishna Hospital' },
      { patientName: 'Sowmya Suresh', ambulanceType: 'Emergency', time: '10:30 AM', location: 'Madhapur, Hyderabad', hospitalName: 'Sree Udhay Hospitals' },
      { patientName: 'Kiran Kumar', ambulanceType: 'Non-Emergency', time: '4:30 PM', location: 'Habsiguda, Hyderabad', hospitalName: 'Chiranjeevi Hospitals' },
      { patientName: 'Jaya Prakash', ambulanceType: 'Emergency', time: '11:00 AM', location: 'Rajendranagar, Hyderabad', hospitalName: 'Ramakrishna Hospitals' }
    ];
  };

  const handleNavigate = (route) => {
    navigate(route);
  };

  return (
    <div className="ambulance-container">
      <h2>Ambulance Bookings for {hospitalName}</h2>

      {data.length > 0 ? (
        <table className="ambulance-table">
          <thead>
            <tr>
              <th>Patient Name</th>
              <th>Ambulance Type</th>
              <th>Time</th>
              <th>Location</th>
              <th>Hospital</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, idx) => (
              <tr key={idx}>
                <td>{item.patientName}</td>
                <td>{item.ambulanceType}</td>
                <td>{item.time}</td>
                <td>{item.location}</td>
                <td>{item.hospitalName}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No ambulance bookings available.</p>
      )}

      <div className="button-container">
        <button className="navigation-button" onClick={() => handleNavigate('/admin/medicines')}>
          Medicines Deliveries
        </button>
        <button className="navigation-button" onClick={() => handleNavigate('/admin/appointments')}>
          Appointments
        </button>
      </div>
    </div>
  );
};

export default Ambulance;
