import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Admin.css';

const Admin = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate('/admin-login'); // Updated path
  };

  return (
    <div className="admin-container">
      <h2>Welcome to Admin Section</h2>
      <button className="admin-btn" onClick={handleClick}>
        Login/Signup as Admin
      </button>
    </div>
  );
};

export default Admin;