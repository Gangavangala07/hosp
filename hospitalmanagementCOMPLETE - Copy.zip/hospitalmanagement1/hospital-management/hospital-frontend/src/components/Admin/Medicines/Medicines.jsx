import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Medicines.css'; // Import the CSS file for styling

const Medicines = () => {
  const [data, setData] = useState([]);
  const hospitalName = localStorage.getItem('hospitalName');
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .post('http://localhost:5000/api/admin-medicines', { hospitalName })
      .then((res) => {
        if (res.data.length > 0) {
          setData(res.data);
        } else {
          const dummyData = getDummyData(hospitalName);
          setData(dummyData);
        }
      })
      .catch((err) => {
        console.error(err);
        const dummyData = getDummyData(hospitalName);
        setData(dummyData);
      });
  }, [hospitalName]);

  const getDummyData = (hospitalName) => {
    return [
      { patientName: 'Aditi Rao', medicineName: 'Paracetamol', quantity: 2, location: 'Gachibowli, Hyderabad', hospitalName: 'IMS Hospital' },
      { patientName: 'Ravi Kumar', medicineName: 'Ibuprofen', quantity: 1, location: 'Kondapur, Hyderabad', hospitalName: 'Apollo Hospital' },
      { patientName: 'Meena Singh', medicineName: 'Cough Syrup', quantity: 1, location: 'Madhapur, Hyderabad', hospitalName: 'Care Hospital' },
      { patientName: 'Nikhil Reddy', medicineName: 'Vitamin C', quantity: 3, location: 'Lingampally, Hyderabad', hospitalName: 'KIMS Hospitals' },
      { patientName: 'Ananya Gupta', medicineName: 'Amoxicillin', quantity: 1, location: 'HiTech City, Hyderabad', hospitalName: 'Yashoda Hospital' },
      { patientName: 'Vikram Chauhan', medicineName: 'Insulin', quantity: 2, location: 'Gachibowli, Hyderabad', hospitalName: 'Aster Prime Hospital' },
      { patientName: 'Sneha Patil', medicineName: 'Zincovit', quantity: 1, location: 'Miyapur, Hyderabad', hospitalName: 'Rainbow Children’s Hospital' },
      { patientName: 'Akhil Sharma', medicineName: 'Metformin', quantity: 2, location: 'KPHB, Hyderabad', hospitalName: 'Asian Institute of Gastroenterology' },
      { patientName: 'Pooja Jain', medicineName: 'Levocetirizine', quantity: 1, location: 'Chandanagar, Hyderabad', hospitalName: 'Narayana Multispeciality Hospital' },
      { patientName: 'Ramesh Yadav', medicineName: 'Antacid Gel', quantity: 1, location: 'Banjara Hills, Hyderabad', hospitalName: 'Mediciti Hospital' },
      { patientName: 'Shruti Verma', medicineName: 'Pain Relief Balm', quantity: 1, location: 'Kukatpally, Hyderabad', hospitalName: 'Pace Hospitals' },
      { patientName: 'Tarun Desai', medicineName: 'Cetrizine', quantity: 2, location: 'Begumpet, Hyderabad', hospitalName: 'Medicover Hospitals' },
      { patientName: 'Divya Sharma', medicineName: 'Erythromycin', quantity: 2, location: 'SR Nagar, Hyderabad', hospitalName: 'Cure Hospital' },
      { patientName: 'Sagar Mehta', medicineName: 'Cold & Flu Tabs', quantity: 1, location: 'Ameerpet, Hyderabad', hospitalName: 'Osmania General Hospital' },
      { patientName: 'Aarti Pillai', medicineName: 'B Complex', quantity: 3, location: 'Gachibowli, Hyderabad', hospitalName: 'MaxCure Hospitals' },
      { patientName: 'Yash Raj', medicineName: 'Loratadine', quantity: 2, location: 'Manikonda, Hyderabad', hospitalName: 'Global Hospital' },
      { patientName: 'Ritika Bose', medicineName: 'Thyroxine', quantity: 1, location: 'Dilsukhnagar, Hyderabad', hospitalName: 'Medwin Hospitals' },
      { patientName: 'Kiran Joshi', medicineName: 'Antibiotics Combo', quantity: 2, location: 'Gachibowli, Hyderabad', hospitalName: 'Care Institute of Medical Sciences' },
      { patientName: 'Neha Kaur', medicineName: 'Vitamin D3', quantity: 1, location: 'Uppal, Hyderabad', hospitalName: 'Sunshine Hospital' },
      { patientName: 'Rahul Tiwari', medicineName: 'Azithromycin', quantity: 2, location: 'Gachibowli, Hyderabad', hospitalName: 'Rocky Hospital' }
    ];
  };

  const handleNavigate = (route) => {
    navigate(route);
  };

  return (
    <div className="medicines-container">
      <h2>Medicine Deliveries for {hospitalName}</h2>

      {data.length > 0 ? (
        <table className="medicine-table">
          <thead>
            <tr>
              <th>Patient Name</th>
              <th>Medicine Name</th>
              <th>Quantity</th>
              <th>Location</th>
              <th>Hospital</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, idx) => (
              <tr key={idx}>
                <td>{item.patientName}</td>
                <td>{item.medicineName}</td>
                <td>{item.quantity}</td>
                <td>{item.location}</td>
                <td>{item.hospitalName}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No medicine deliveries available.</p>
      )}

      <div className="button-container">
        <button className="navigation-button" onClick={() => handleNavigate('/admin/appointments')}>
          Appointments
        </button>
        <button className="navigation-button" onClick={() => handleNavigate('/admin/ambulance')}>
          Ambulance Bookings
        </button>
      </div>
    </div>
  );
};

export default Medicines;
