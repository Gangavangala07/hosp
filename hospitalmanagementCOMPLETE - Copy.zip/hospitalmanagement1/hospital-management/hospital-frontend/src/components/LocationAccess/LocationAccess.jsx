// src/components/LocationAccess/LocationAccess.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './LocationAccess.css';

const LocationAccess = ({ setLocationGranted }) => {
  const [locationName, setLocationName] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchAddress = async (lat, lng) => {
      try {
        const res = await axios.get(
          `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=YOUR_GOOGLE_API_KEY`
        );

        if (res.data.results.length > 0) {
          const address = res.data.results[0].formatted_address;
          setLocationName(address);
          setLocationGranted(true); // Location granted, move to the next page
        } else {
          setError('No address found.');
        }
      } catch (err) {
        setError('Error fetching address.');
      }
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          fetchAddress(latitude, longitude);
        },
        () => setError('Location access denied.'),
        { enableHighAccuracy: true }
      );
    } else {
      setError('Geolocation not supported.');
    }
  }, [setLocationGranted]);

  return (
    <div className="location-access-container">
      <h2>Allow Location Access</h2>
      {locationName ? (
        <p>Your location: {locationName}</p>
      ) : (
        <p>{error || 'Detecting your location...'}</p>
      )}
    </div>
  );
};

export default LocationAccess;
