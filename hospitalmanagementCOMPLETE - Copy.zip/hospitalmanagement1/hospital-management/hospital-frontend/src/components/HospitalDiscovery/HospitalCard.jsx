import React from 'react';
import { useNavigate } from 'react-router-dom';
import './HospitalCard.css';

const HospitalCard = ({ hospital }) => {
  const navigate = useNavigate();

  const handleAmbulanceBooking = () => {
    navigate('/ambulance', {
      state: {
        hospitalName: hospital.name,
        location: `${hospital.city}, ${hospital.state}`,
      },
    });
  };

  const handleMedicineBooking = () => {
    navigate('/medicine', {
      state: {
        hospitalName: hospital.name,
        location: `${hospital.city}, ${hospital.state}`,
      },
    });
  };

  const handleAppointmentBooking = (doctorName) => {
    navigate('/opbookingform', {
      state: {
        hospitalName: hospital.name,
        doctorName,
        location: `${hospital.city}, ${hospital.state}`,
      },
    });
  };

  return (
    <div className="hospital-card">
      <div className="hospital-header">
        <h3 className="hospital-name">{hospital.name}</h3>
        <p className="hospital-address">
          <strong>Address:</strong> {hospital.address}, {hospital.city}, {hospital.state}
        </p>
      </div>

      <div className="hospital-details">
        <p><strong>Availability:</strong> {hospital.availability}</p>
        <p><strong>Phone:</strong> {hospital.phone}</p>

        {hospital.features && hospital.features.length > 0 && (
          <p><strong>Facilities:</strong> {hospital.features.join(', ')}</p>
        )}
      </div>

      <div className="hospital-actions">
        <button className="action-btn" onClick={handleAmbulanceBooking}>
          <i className="fa fa-ambulance"></i> Book Ambulance
        </button>
        <button className="action-btn" onClick={handleMedicineBooking}>
          <i className="fa fa-pills"></i> Order Medicine
        </button>
      </div>

      {hospital.doctors && hospital.doctors.length > 0 && (
        <div className="doctor-bookings">
          <p className="doctors-header"><strong>Doctors Available:</strong></p>
          {hospital.doctors.map((doctor, index) => (
            <div key={index} className="doctor-item">
              <span className="doctor-name">{doctor.name} ({doctor.specialization})</span>
              <button className="appointment-btn" onClick={() => handleAppointmentBooking(doctor.name)}>
                Book Appointment
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HospitalCard;
