import React, { useState, useEffect } from 'react';
import axios from 'axios';
import HospitalCard from './HospitalCard';
import './HospitalList.css';

const HospitalList = () => {
  const [hospitals, setHospitals] = useState([]);
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showInput, setShowInput] = useState(true);

  useEffect(() => {
    const savedLocation = localStorage.getItem('userLocation');
    if (savedLocation) {
      setLocation(savedLocation);
      setShowInput(false);
      fetchHospitals(savedLocation);
    }
  }, []);

  const fetchHospitals = async (inputLocation) => {
    const loc = inputLocation || location;
    if (!loc.trim()) {
      setErrorMsg('Please enter a valid location.');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    try {
      const response = await axios.get(`http://localhost:5000/api/get-hospitals-by-location`, {
        params: { location: loc }
      });

      const hospitalsData = response.data?.data || [];
      setHospitals(hospitalsData);

      if (hospitalsData.length === 0) {
        setErrorMsg("No hospitals found for this location.");
      } else {
        setErrorMsg('');
      }

      setShowInput(false);
      localStorage.setItem('userLocation', loc);
    } catch (error) {
      console.error("Error fetching hospitals:", error);
      setHospitals([]);
      setErrorMsg('Error fetching hospitals.');
    } finally {
      setLoading(false);
    }
  };

  const handleLocationChange = () => {
    setShowInput(true);
    setLocation('');
    setHospitals([]);
    localStorage.removeItem('userLocation');
  };

  return (
    <div className="hospital-discovery-container">
      <h2>Find Hospitals</h2>

      {showInput ? (
        <div className="location-input-wrapper">
          <input
            type="text"
            placeholder="Enter location (e.g., Hanamkonda or Hyderabad)"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="location-input"
          />
          <button onClick={() => fetchHospitals(location)} className="search-button">
            Search
          </button>
        </div>
      ) : (
        <>
          <p><strong>Location:</strong> {location}</p>
          <button className="change-location-button" onClick={handleLocationChange}>
            Change Location
          </button>
        </>
      )}

      {loading && <div className="loading-spinner">Loading hospitals...</div>}
      {errorMsg && <div className="error-message">{errorMsg}</div>}

      <div className="results-section">
        {hospitals.map((hospital, index) => (
          <HospitalCard key={index} hospital={hospital} />
        ))}
      </div>
    </div>
  );
};

export default HospitalList;
