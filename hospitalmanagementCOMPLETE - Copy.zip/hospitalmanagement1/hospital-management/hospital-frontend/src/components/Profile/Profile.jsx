import React from 'react';
import { useNavigate } from 'react-router-dom';
import './profile.css'; // Importing the CSS

const Profile = () => {
  const navigate = useNavigate();
  const username = localStorage.getItem('userName') || 'Guest'; // Fetch the actual username or set default to 'Guest'

  return (
    <div className="profile-container">
      <h2>Welcome {username}👋</h2>

      <div className="profile-actions">
        <button onClick={() => navigate('/account-details')} className="profile-button">
          Account Details
        </button>
      </div>
    </div>
  );
};

export default Profile;
