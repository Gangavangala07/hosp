// components/Profile/AccountDetails/AccountDetails.js

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AccountDetails.css';

const AccountDetails = () => {
  const [userDetails, setUserDetails] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Get data from localStorage
    const userName = localStorage.getItem('userName');
    const userEmail = localStorage.getItem('userEmail');
    const userId = localStorage.getItem('userId');

    // Redirect to login if not available
    if (!userName || !userEmail || !userId) {
      navigate('/');
    } else {
      setUserDetails({
        name: userName,
        email: userEmail,
        userId: userId,
      });
    }
  }, [navigate]);

  return (
    <div className="account-wrapper">
      <div className="account-box">
        <h2>Account Details</h2>
        {userDetails ? (
          <div className="details">
            <p><strong>Name:</strong> {userDetails.name}</p>
            <p><strong>Email:</strong> {userDetails.email}</p>
            <p><strong>User ID:</strong> {userDetails.userId}</p>
          </div>
        ) : (
          <p>Loading...</p>
        )}
      </div>
    </div>
  );
};

export default AccountDetails;
