import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// User Components
import LoginSignup from './components/LoginSignup/LoginSignup';
import HospitalList from './components/HospitalDiscovery/HospitalList';
import Tracking from './components/Tracking/Tracking';
import OPBookingForm from './components/OPBooking/OPBookingForm';
import AmbulanceBooking from './components/AmbulanceBooking/AmbulanceBooking';
import MedicineDelivery from './components/Medicine/MedicineDelivery';
import Dashboard from './components/Dashboard/Dashboard';
import Navbar from './components/Navbar/Navbar';
import Doctors from './components/Doctors/Doctors';
import Profile from './components/Profile/Profile';
import History from './components/History/History';
import AccountDetails from './components/Profile/AccountDetails/AccountDetails';
import Admin from './components/Admin/Admin/Admin';

// ✅ Admin Components
import AdminDashboard from './components/Admin/Dashboard/AdminDashboard';
import AdminLogin from './components/Admin/AdminLogin/AdminLoginSignup';
import Appointment from './components/Admin/Appointment/Appointment';
import Ambulance from './components/Admin/Ambulance/Ambulance';
import Medicines from './components/Admin/Medicines/Medicines';

import './App.css';
import AdminLoginSignup from './components/Admin/AdminLogin/AdminLoginSignup';

// ✅ User Private Route
const PrivateRoute = ({ element }) => {
  const isAuthenticated = localStorage.getItem("userToken");
  return isAuthenticated ? element : <Navigate to="/" replace />;
};

// ✅ Admin Private Route
const AdminRoute = ({ element }) => {
  const isAdminAuthenticated = localStorage.getItem("isAdminLoggedIn");
  return isAdminAuthenticated ? element : <Navigate to="/admin-login" replace />;
};

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        {/* ✅ Public Routes */}
        <Route path="/" element={<LoginSignup />} />
        <Route path="/admin-login" element={<AdminLogin />} />

        {/* ✅ Protected User Routes */}
        <Route path="/dashboard" element={<PrivateRoute element={<Dashboard />} />} />
        <Route path="/hospitals" element={<PrivateRoute element={<HospitalList />} />} />
        <Route path="/appointment" element={<PrivateRoute element={<OPBookingForm />} />} />
        <Route path="/opbookingform" element={<PrivateRoute element={<OPBookingForm />} />} />
        <Route path="/ambulance" element={<PrivateRoute element={<AmbulanceBooking />} />} />
        <Route path="/medicine" element={<PrivateRoute element={<MedicineDelivery />} />} />
        <Route path="/doctors" element={<PrivateRoute element={<Doctors />} />} />
        <Route path="/tracking" element={<PrivateRoute element={<Tracking />} />} />
        <Route path="/profile" element={<PrivateRoute element={<Profile />} />} />
        <Route path="/history" element={<PrivateRoute element={<History />} />} />
        <Route path="/account-details" element={<PrivateRoute element={<AccountDetails />} />} />
          <Route path="/admin" element={<Admin />} />
        {/* ✅ Protected Admin Routes */}
        <Route path="/admin-login" element={<AdminLoginSignup />} />
        <Route path="/admin/admindashboard" element={<AdminRoute element={<AdminDashboard />} />} />
        <Route path="/admin/appointments" element={<AdminRoute element={<Appointment />} />} />
        <Route path="/admin/ambulance" element={<AdminRoute element={<Ambulance />} />} />
        <Route path="/admin/medicines" element={<AdminRoute element={<Medicines />} />} />
      </Routes>
    </Router>
  );
}

export default App;
